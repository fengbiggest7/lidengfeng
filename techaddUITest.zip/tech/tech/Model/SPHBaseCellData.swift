//
//  SPHBaseCellData.swift
//  tech
//
//  Created by fengbiggest7 on 2020/4/4.
//  Copyright © 2020年 SPH. All rights reserved.
//

import UIKit

class SPHBaseCellData: NSObject {
    var quarter = ""
    var volume_of_mobile_data = ""
    var islow = 0
}

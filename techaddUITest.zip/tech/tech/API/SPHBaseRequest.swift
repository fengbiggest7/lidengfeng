//
//  SPHBaseRequest.swift
//  tech
//
//  Created by fengbiggest7 on 2020/4/4.
//  Copyright © 2020年 SPH. All rights reserved.
//

import UIKit
class SPHBaseRequest: NSObject {
    func getDataQuarter(quarter:String,datas:Array<SPHBaseData>) -> SPHBaseCellData {
        let baseData = SPHBaseCellData()
        let filterDatas = datas.filter { (item) -> Bool in
            return item.quarter.contains(quarter)
        }
        
        baseData.quarter = quarter
        
//        baseData.volume_of_mobile_data = String(stringInterpolationSegment: filterDatas.reduce(0.0, { (volume, element) -> Double in
//            let total = volume + Double(element.volume_of_mobile_data)!
//            return total
//        }))
        var total = 0.0
        var flag = 0.0
        for i in 0..<filterDatas.count{
            total = total + Double(filterDatas[i].volume_of_mobile_data)!
            if flag > Double(filterDatas[i].volume_of_mobile_data)!{
                baseData.islow = 1
            }
            flag = Double(filterDatas[i].volume_of_mobile_data)!
        }
        baseData.volume_of_mobile_data = String(stringInterpolationSegment: total)
        
        return baseData
    }
    func getNewsData(resource_id:String,limit:Int,completion:@escaping (Any,Bool)->Void) -> Void {
        //把参数拼接到网址字符串上 https://data.gov.sg/api/action/datastore_search?resource_id=a807b7ab-6cad-4aa6-87d0-e283a7353a0f&limit=5
        var urlStr = "https://data.gov.sg/api/action/datastore_search?offset=14&resource_id=\(resource_id)&limit=\(limit)"
        //如果有汉字，进行转码
        urlStr = urlStr.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlFragmentAllowed)!
        //封装为URL对象
        print(urlStr)
        let url = URL(string: urlStr)
        //封装为URLRequest对象
        let req = URLRequest(url: url!, cachePolicy: .reloadIgnoringCacheData, timeoutInterval: 5.0)
        let task:URLSessionDataTask = URLSession.shared.dataTask(with: req) { (data, response, error) in
            //json数据解析
            let jsonData = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments)
            print(jsonData!)
            //json解析失败，返回错误信息


            let status = (jsonData as! NSDictionary).value(forKey: "success") as! Int

            if Int(status) != 1{
                completion("加载数据失败",false)
                return
            }

            let result = (jsonData as! NSDictionary).value(forKey: "result") as! NSDictionary
            let list = result.value(forKey: "records") as! NSArray
            var newsArr:[SPHBaseData] = []
            
            for item in list{
                let dic = item as! NSDictionary
                let oneNew = SPHBaseData()
                oneNew._id = String(stringInterpolationSegment:dic.value(forKey: "_id"))
                oneNew.quarter = dic.value(forKey: "quarter") as! String
                oneNew.volume_of_mobile_data = dic.value(forKey: "volume_of_mobile_data") as! String
                newsArr.append(oneNew)
            }
            var Arrs:[SPHBaseCellData] = []
            for i in 2008..<2019{
                Arrs.append(self.getDataQuarter(quarter: "\(i)", datas: newsArr))
            }
            completion(Arrs,true)
        }
        //开启任务
        task.resume()
    }
}

//
//  techTests.swift
//  techTests
//
//  Created by fengbiggest7 on 2020/4/4.
//  Copyright © 2020年 SPH. All rights reserved.
//

import XCTest
@testable import tech

class techTests: XCTestCase {
    var baseQuest:SPHBaseRequest = SPHBaseRequest()
    //每个测试方法调用前执行
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
        print("starting test ")
    }
    //每个测试方法调用后执行
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        print("end test")
        super.tearDown()
    }
    //测试方法
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
    func testGetDataQuarter() {
        let data0:SPHBaseData = SPHBaseData()
        data0._id = "10"
        data0.quarter = "2011-Q1"
        data0.volume_of_mobile_data = "2.12313"
        let data1:SPHBaseData = SPHBaseData()
        data0._id = "10"
        data0.quarter = "2011-Q2"
        data0.volume_of_mobile_data = "2.02313"
        let data2:SPHBaseData = SPHBaseData()
        data0._id = "10"
        data0.quarter = "2011-Q3"
        data0.volume_of_mobile_data = "2.12313"
        let data3:SPHBaseData = SPHBaseData()
        data0._id = "10"
        data0.quarter = "2011-Q4"
        data0.volume_of_mobile_data = "2.12313"
        let arr:Array = [data0,data1,data2,data3]
        
        let result = baseQuest.getDataQuarter(quarter: "2011", datas: arr)
        XCTAssert(result.islow == 1, "error: Unexpected result")
        XCTAssert(Double(result.volume_of_mobile_data)! == 8.39252, "error: Unexpected result")
    }
    
    func testGetNewsData(){
        baseQuest.getNewsData(resource_id: "a807b7ab-6cad-4aa6-87d0-e283a7353a0f", limit: 44) { (data, success) in
            XCTAssert(success , "error:request fail")
        }
        
    }
    
}

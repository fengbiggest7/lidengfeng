//
//  ViewController.swift
//  tech
//
//  Created by fengbiggest7 on 2020/4/4.
//  Copyright © 2020年 SPH. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    var tab:UITableView?
    
    var tableDataArr : [SPHBaseCellData]?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.tab = UITableView(frame: self.view.frame, style: .plain)
        self.tab?.dataSource = self;
        self.tab?.delegate = self;
        self.view .addSubview(self.tab!)
        self.tableDataArr = []
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.requestNetWorkDataAndUpdataUI()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.tableDataArr?.count)!
    }
    //MARK:UITableViewDataSource
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellid = "ItemCellID"
        var cell = tableView.dequeueReusableCell(withIdentifier: cellid)
        if cell==nil {
            cell = UITableViewCell(style: .subtitle, reuseIdentifier: cellid)
        }
        if self.tableDataArr?[indexPath.row].islow == 1 {
            cell?.backgroundColor = UIColor .red
        }
        
        cell?.textLabel?.text = self.tableDataArr?[indexPath.row].quarter
        cell?.detailTextLabel?.text = self.tableDataArr?[indexPath.row].volume_of_mobile_data
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if self.tableDataArr?[indexPath.row].islow == 1 {
            DispatchQueue.main.async(execute: {
                let alertVC = UIAlertController(title: "警告", message: "当年季度有数据量下降", preferredStyle: .alert)
                let confirmBtn = UIAlertAction(title: "确定", style: .default, handler: nil)
                alertVC.addAction(confirmBtn)
                self.present(alertVC, animated: true, completion: nil)
            })
        }
    }    
    
    func requestNetWorkDataAndUpdataUI() -> Void {
        let urlSerive = SPHBaseRequest()
        urlSerive.getNewsData(resource_id: "a807b7ab-6cad-4aa6-87d0-e283a7353a0f", limit: 44) { (data, success) in
            self.tableDataArr = (data as! [SPHBaseCellData])
            DispatchQueue.main.async(execute: {
                self.tab?.reloadData()
            })
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

